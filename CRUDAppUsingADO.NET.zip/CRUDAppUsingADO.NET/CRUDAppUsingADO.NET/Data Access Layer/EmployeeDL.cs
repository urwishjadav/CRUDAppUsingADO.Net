﻿using CRUDAppUsingADO.NET.Models;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Globalization;

namespace CRUDAppUsingADO.NET.Data_Access_Layer
{
    public class EmployeeDL
    {
        //get the connection string
        string DefaultConnection = ConnectionString.dc;

        //all emp get method
        public List<Employees> getAllEmps()
        {
            List<Employees> empList = new List<Employees>();

            //sql connection manage by below block
            //It used bcs we dont need to close our connection when we use using block we just need to open connection
            //in SqlConnection pass our varname DefaultConnection its imp
            using (SqlConnection con = new SqlConnection(DefaultConnection))
            {
                //SqlCommand used when we need to Execute SP or SQL query
                SqlCommand cmd = new SqlCommand("spGetAllEmployee", con);
                //to sql command we need to tell them its SP else it will act its just normal text so define below code is imp
                cmd.CommandType = CommandType.StoredProcedure;

                //when we need to open our connection below code | dont need to close the connection
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                //in this loop data will read all the data till data not end
                //Read() method will run till reader haves the data in it.
                while (reader.Read())
                {
                    Employees emp = new Employees();
                    emp.Id = Convert.ToInt32(reader["Id"]);
                    emp.Name = reader["name"].ToString() ?? "";
                    emp.Gender = reader["gender"].ToString() ?? "";
                    emp.Age = Convert.ToInt32(reader["Age"]);
                    emp.Designation = reader["designation"].ToString() ?? "";
                    emp.City = reader["city"].ToString() ?? "";
                    empList.Add(emp);

                }
            }
            return empList;
        }


        //edit 
        //use model class name to create method
        public Employees GetEmployeeById(int? id)
        {
            Employees emp = new Employees();
            using (SqlConnection con = new SqlConnection(DefaultConnection))
            {
                SqlCommand cmd = new SqlCommand("select * from employees where id = @id", con);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@id", id);

                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    emp.Id = Convert.ToInt32(reader["Id"]);
                    emp.Name = reader["name"].ToString() ?? "";
                    emp.Gender = reader["gender"].ToString() ?? "";
                    emp.Age = Convert.ToInt32(reader["Age"]);
                    emp.Designation = reader["designation"].ToString() ?? "";
                    emp.City = reader["city"].ToString() ?? "";

                }
            }
            return emp;
        }

        //Create
        public void AddEmployee(Employees emp)
        {
            using (SqlConnection con = new SqlConnection(DefaultConnection))
            {
                SqlCommand cmd = new SqlCommand("spAddEmployee", con);
                cmd.CommandType = CommandType.StoredProcedure;

                //parameter's value we provide below
                cmd.Parameters.AddWithValue("@name", emp.Name);
                cmd.Parameters.AddWithValue("@gender", emp.Gender);
                cmd.Parameters.AddWithValue("@age", emp.Age);
                cmd.Parameters.AddWithValue("@designation", emp.Designation);
                cmd.Parameters.AddWithValue("@city", emp.City);

                con.Open();
                cmd.ExecuteNonQuery();

            }
        }



        //Update
        public void UpdateEmployee(Employees emp)
        {
            using (SqlConnection con = new SqlConnection(DefaultConnection))
            {
                SqlCommand cmd = new SqlCommand("spUpdateEmployee", con);
                cmd.CommandType = CommandType.StoredProcedure;

                //parameter's value we provide below
                cmd.Parameters.AddWithValue("@id", emp.Id);
                cmd.Parameters.AddWithValue("@name", emp.Name);
                cmd.Parameters.AddWithValue("@gender", emp.Gender);
                cmd.Parameters.AddWithValue("@age", emp.Age);
                cmd.Parameters.AddWithValue("@designation", emp.Designation);
                cmd.Parameters.AddWithValue("@city", emp.City);

                con.Open();
                cmd.ExecuteNonQuery();

            }
        }

        //Delete
        public void DeleteEmployee(int? id)
        {
            using (SqlConnection con = new SqlConnection(DefaultConnection))
            {
                SqlCommand cmd = new SqlCommand("spDeleteEmployee", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", id);

                con.Open();
                cmd.ExecuteNonQuery();

            }
        }
    }
}
