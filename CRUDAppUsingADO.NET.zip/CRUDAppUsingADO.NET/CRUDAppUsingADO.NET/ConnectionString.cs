﻿namespace CRUDAppUsingADO.NET
{
    public static class ConnectionString
    {
        private static string DefaultConnection = "Server=DESKTOP-DNF6O9U\\SQLEXPRESS;Database=CrudADOdb; Trusted_Connection=True;";
        public static string dc { get => DefaultConnection; }
    }
}
