﻿using CRUDAppUsingADO.NET.Data_Access_Layer;
using CRUDAppUsingADO.NET.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace CRUDAppUsingADO.NET.Controllers
{
    public class HomeController : Controller
    {
        private readonly EmployeeDL DL;
        public HomeController()
        {
                DL = new EmployeeDL();
        }

        public IActionResult Index()
        {
            //accessing getAllEmps method by using obj of EmployeeDL class
            List<Employees> emps = DL.getAllEmps();
            return View(emps);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken] //it used to secure our form submission 
        public IActionResult Create(Employees emp)
        {
            try
            {
                DL.AddEmployee(emp);
                return RedirectToAction("Index");
            }
            catch (Exception)
            {

                return View();

            }
        }
        public IActionResult Edit(int id)
        {
            Employees emp = DL.GetEmployeeById(id);
            return View(emp);
        }

        [HttpPost]
        [ValidateAntiForgeryToken] //it used to secure our form submission 
        //for update 
        public IActionResult Edit(Employees emp)
        {
            try
            {
                DL.UpdateEmployee(emp);
                return RedirectToAction("Index");
            }
            catch (Exception)
            {

                return View();

            }
        }

        public IActionResult Details(int id)
        {
            Employees emp = DL.GetEmployeeById(id);
            return View(emp);
        }

        public IActionResult Delete(int id)
        {
            Employees emp = DL.GetEmployeeById(id);
            return View(emp);
        }

        [HttpPost]
        [ValidateAntiForgeryToken] //it used to secure our form submission 
        public IActionResult Delete(Employees emp)
        {
            try
            {
                DL.DeleteEmployee(emp.Id);
                return RedirectToAction("Index");
            }
            catch (Exception)
            {

                return View();

            }
        }
        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}